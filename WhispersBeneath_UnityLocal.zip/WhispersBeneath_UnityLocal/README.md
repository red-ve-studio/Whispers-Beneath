# WhispersBeneath_UnityLocal

This is a Unity horror-thriller game project by Red Veil Studio.

## Features:
- Local multiplayer (2 players)
- Flashlight system
- Simple AI monster
- Creepy underground level (basic layout)
- GitHub-ready structure

## How to Use:
1. Open Unity Hub.
2. Click "Open" and select this folder.
3. Run the scene in `Assets/Scenes/Main.unity`.

You can expand this project to online multiplayer later.
