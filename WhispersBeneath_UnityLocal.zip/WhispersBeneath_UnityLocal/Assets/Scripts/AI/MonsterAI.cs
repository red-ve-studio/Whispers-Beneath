using UnityEngine;
using UnityEngine.AI;

public class MonsterAI : MonoBehaviour
{
    public Transform target;
    public NavMeshAgent agent;

    void Update()
    {
        if (target != null)
        {
            agent.SetDestination(target.position);
        }
    }
}
